<?php
session_start();

// Jika sudah login, langsung lempar ke halaman kasir utama (index.php)
if (isset($_SESSION['login'])) {
    header("Location: index.php");
    exit;
}

// Koneksi ke database
$koneksi = mysqli_connect("localhost", "root", "", "kasir_kelompok2");

$error = "";
if (isset($_POST['login'])) {
    $username = mysqli_real_escape_string($koneksi, $_POST['username']);
    $password = $_POST['password'];

    $result = mysqli_query($koneksi, "SELECT * FROM users WHERE username = '$username'");

    // Perbaikan fungsi pengecekan baris database
    if ($result && mysqli_num_rows($result) === 1) {
        $row = mysqli_fetch_assoc($result);
        
        // Verifikasi password (cocokkan teks langsung atau hash)
        if ($password === $row['password'] || password_verify($password, $row['password'])) {
            $_SESSION['login'] = true;
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['username'] = $row['username'];
            $_SESSION['full_name'] = $row['full_name'];
            $_SESSION['role'] = $row['role'];

            header("Location: index.php");
            exit;
        } else {
            $error = "Password yang Anda masukkan salah!";
        }
    } else {
        $error = "Username tidak ditemukan!";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login - Sistem Kasir Modern</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Inter', sans-serif;
    }
    body {
      background: #f0f2f5;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      padding: 20px;
    }
    .login-container {
      display: flex;
      max-width: 900px;
      width: 100%;
      background: #fff;
      border-radius: 12px;
      box-shadow: 0 8px 24px rgba(0,0,0,0.1);
      overflow: hidden;
    }
    .login-left {
      flex: 1;
      background: linear-gradient(135deg, #1e293b, #0f172a);
      color: #fff;
      padding: 40px;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .login-left i {
      font-size: 4rem;
      color: #38bdf8;
      margin-bottom: 15px;
    }
    .login-left h1 {
      font-size: 1.8rem;
      font-weight: 700;
      margin-bottom: 10px;
    }
    .login-left p {
      color: #94a3b8;
      font-size: 0.95rem;
    }
    .login-right {
      flex: 1;
      padding: 40px;
      display: flex;
      flex-direction: column;
      justify-content: center;
    }
    .login-right h2 {
      font-size: 1.5rem;
      color: #1e293b;
      margin-bottom: 5px;
    }
    .login-right p {
      color: #64748b;
      font-size: 0.9rem;
      margin-bottom: 25px;
    }
    .form-group {
      margin-bottom: 18px;
    }
    .form-group label {
      display: block;
      font-size: 0.85rem;
      font-weight: 600;
      color: #334155;
      margin-bottom: 6px;
    }
    .input-wrapper {
      position: relative;
    }
    .input-wrapper i {
      position: absolute;
      left: 12px;
      top: 50%;
      transform: translateY(-50%);
      color: #94a3b8;
    }
    .input-wrapper input {
      width: 100%;
      padding: 12px 12px 12px 38px;
      border: 1px solid #cbd5e1;
      border-radius: 8px;
      font-size: 0.95rem;
      outline: none;
      transition: all 0.2s;
    }
    .input-wrapper input:focus {
      border-color: #0284c7;
      box-shadow: 0 0 0 3px rgba(2, 132, 199, 0.15);
    }
    .btn-login {
      width: 100%;
      padding: 12px;
      background: #0284c7;
      color: #fff;
      border: none;
      border-radius: 8px;
      font-size: 1rem;
      font-weight: 600;
      cursor: pointer;
      transition: background 0.2s;
      margin-top: 10px;
    }
    .btn-login:hover {
      background: #0369a1;
    }
    .alert-danger {
      background: #fef2f2;
      border: 1px solid #fecaca;
      color: #dc2626;
      padding: 10px 12px;
      border-radius: 8px;
      font-size: 0.85rem;
      margin-bottom: 20px;
    }
    @media (max-width: 768px) {
      .login-container {
        flex-direction: column;
      }
      .login-left {
        padding: 30px;
      }
    }
  </style>
</head>
<body>

  <div class="login-container">
    <div class="login-left">
      <i class="fa-solid fa-cash-register"></i>
      <h1>KasirKelompk 2</h1>
      <p>Sistem Kasir Modern & Transaksi Cepat</p>
    </div>

    <div class="login-right">
      <h2>Selamat Datang</h2>
      <p>Silakan masuk ke akun Anda</p>

      <?php if (!empty($error)) : ?>
        <div class="alert-danger">
          <i class="fa-solid fa-circle-exclamation"></i> <?= $error; ?>
        </div>
      <?php endif; ?>

<form action="" method="POST">
        <div class="form-group">
          <label for="username">Username</label>
          <div class="input-wrapper">
            <i class="fa-solid fa-user"></i>
            <input type="text" name="username" id="username" placeholder="usernamenya beb" required autofocus>
          </div>
        </div>

        <div class="form-group">
          <label for="password">Password</label>
          <div class="input-wrapper">
            <i class="fa-solid fa-lock"></i>
            <input type="password" name="password" id="password" placeholder="passnya beb" required>
          </div>
        </div>

        <button type="submit" name="login" class="btn-login">
          <i class="fa-solid fa-right-to-bracket"></i> Masuk Sekarang
        </button>
      </form>
    </div>
  </div>

</body>
</html>