<?php
session_start();

// Koneksi ke database MySQL
$koneksi = mysqli_connect("localhost", "root", "", "kasir_kelompok2");

// Proses Login saat form dikirim
$error = "";
if (isset($_POST['login'])) {
    $username = mysqli_real_escape_string($koneksi, $_POST['username']);
    $password = $_POST['password'];

    $result = mysqli_query($koneksi, "SELECT * FROM users WHERE username = '$username'");

    if ($result && mysqli_num_rows($result) === 1) {
        $row = mysqli_fetch_assoc($result);
        if ($password === $row['password'] || password_verify($password, $row['password'])) {
            $_SESSION['login'] = true;
            $_SESSION['full_name'] = $row['full_name'];
            header("Location: index.php");
            exit;
        } else {
            $error = "Password salah!";
        }
    } else {
        $error = "Username tidak ditemukan!";
    }
}

// Proses Logout
if (isset($_GET['action']) && $_GET['action'] == 'logout') {
    session_destroy();
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sistem Kasir Modern</title>
  <link rel="stylesheet" href="style.css">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

<?php if (!isset($_SESSION['login'])) : ?>
  <!-- ================= TAMPILAN LOGIN (GAYA FACEBOOK) ================= -->
  <style>
    .login-body {
      background: #f0f2f5;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
    }
    .login-card {
      background: #fff;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
      width: 100%;
      max-width: 400px;
    }
    .login-card h2 {
      text-align: center;
      color: #1e293b;
      margin-bottom: 5px;
    }
    .login-card p {
      text-align: center;
      color: #64748b;
      font-size: 0.9rem;
      margin-bottom: 20px;
    }
    .login-group {
      margin-bottom: 15px;
    }
    .login-group label {
      display: block;
      font-size: 0.85rem;
      font-weight: 600;
      color: #334155;
      margin-bottom: 5px;
    }
    .login-group input {
      width: 100%;
      padding: 10px 12px;
      border: 1px solid #cbd5e1;
      border-radius: 8px;
      font-size: 0.95rem;
      outline: none;
      box-sizing: border-box;
    }
    .btn-submit-login {
      width: 100%;
      padding: 12px;
      background: #0284c7;
      color: #fff;
      border: none;
      border-radius: 8px;
      font-weight: 600;
      font-size: 1rem;
      cursor: pointer;
      margin-top: 10px;
    }
    .btn-submit-login:hover {
      background: #0369a1;
    }
    .error-msg {
      background: #fee2e2;
      color: #dc2626;
      padding: 8px;
      border-radius: 6px;
      font-size: 0.85rem;
      margin-bottom: 15px;
      text-align: center;
    }
  </style>

  <div class="login-body">
    <div class="login-card">
      <h2>KasirKelompok 2</h2>
      <p>Silakan login untuk masuk ke sistem</p>

      <?php if (!empty($error)) : ?>
        <div class="error-msg"><i class="fa-solid fa-circle-exclamation"></i> <?= $error; ?></div>
      <?php endif; ?>

      <form method="POST" action="">
        <div class="login-group">
          <label>Username</label>
          <input type="text" name="username" placeholder="usernamenya beb" required autofocus>
        </div>
        <div class="login-group">
          <label>Password</label>
          <input type="password" name="password" placeholder="passnya beb" required>
        </div>
        <button type="submit" name="login" class="btn-submit-login">
          <i class="fa-solid fa-right-to-bracket"></i> Masuk
        </button>
      </form>
    </div>
  </div>

<?php else : ?>
  <!-- ================= TAMPILAN UTAMA KASIR ================= -->
  <div class="app-container">
    <header class="navbar">
      <div class="logo">
        <i class="fa-solid fa-cash-register"></i>
        <span>KasirKelompk 2</span>
      </div>
      <div class="user-info" style="display: flex; align-items: center; gap: 15px;">
        <div>
          <i class="fa-solid fa-user-circle"></i>
          <span>Kasir: <?= htmlspecialchars($_SESSION['full_name']); ?></span>
        </div>
        <a href="index.php?action=logout" onclick="return confirm('Yakin ingin keluar?')" style="background: #ef4444; color: #fff; padding: 6px 12px; border-radius: 6px; text-decoration: none; font-size: 0.85rem; font-weight: 600;">
          <i class="fa-solid fa-right-from-bracket"></i> Logout
        </a>
      </div>
    </header>

    <main class="main-content">
      <section class="products-section">
        <div class="search-bar">
          <i class="fa-solid fa-search"></i>
          <input type="text" id="search-input" placeholder="Cari produk atau scan barcode..." onkeyup="filterProducts()">
        </div>

        <div class="categories" id="categories-container">
          <button class="category-btn active" onclick="filterCategory('all')">Semua</button>
          <button class="category-btn" onclick="filterCategory('Makanan')">Makanan</button>
          <button class="category-btn" onclick="filterCategory('Minuman')">Minuman</button>
          <button class="category-btn" onclick="filterCategory('Snack')">Snack</button>
        </div>

        <div class="product-grid" id="product-grid">
          <!-- Produk dimuat dinamis lewat JS -->
        </div>
      </section>

      <section class="cart-section">
        <div class="cart-header">
          <h2><i class="fa-solid fa-shopping-cart"></i> Keranjang</h2>
          <button class="btn-clear" onclick="clearCart()"><i class="fa-solid fa-trash-can"></i> Bersihkan</button>
        </div>

        <div class="cart-items" id="cart-items">
          <p class="empty-msg">Keranjang masih kosong</p>
        </div>

        <div class="cart-summary">
          <div class="summary-row">
            <span>Subtotal</span>
            <span id="subtotal">Rp 0</span>
          </div>
          <div class="summary-row">
            <span>Pajak (10%)</span>
            <span id="tax">Rp 0</span>
          </div>
          <div class="summary-row total-row">
            <span>Total Akhir</span>
            <span id="grand-total">Rp 0</span>
          </div>

          <div class="payment-input">
            <label for="pay-amount">Uang Diterima (Rp)</label>
            <input type="number" id="pay-amount" placeholder="0" oninput="calculateChange()">
          </div>

          <div class="summary-row change-row">
            <span>Kembalian</span>
            <span id="change-amount">Rp 0</span>
          </div>

          <button class="btn-checkout" id="checkout-btn" onclick="processCheckout()" disabled>
            <i class="fa-solid fa-print"></i> Bayar & Cetak Struk
          </button>
        </div>
      </section>
    </main>
  </div>
  <script src="script.js"></script>
<?php endif; ?>

</body>
</html>