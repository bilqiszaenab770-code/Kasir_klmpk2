// Data Dummy Produk
const products = [
  { id: 1, name: "Nasi Goreng Spesial", price: 25000, category: "Makanan" },
  { id: 2, name: "Mie Goreng Jawa", price: 20000, category: "Makanan" },
  { id: 3, name: "Ayam Bakar + Nasi", price: 28000, category: "Makanan" },
  { id: 4, name: "Es Teh Manis", price: 5000, category: "Minuman" },
  { id: 5, name: "Kopi Hitam", price: 8000, category: "Minuman" },
  { id: 6, name: "Jus Alpukat", price: 15000, category: "Minuman" },
  { id: 7, name: "Kentang Goreng", price: 14000, category: "Snack" },
  { id: 8, name: "Roti Bakar Cokelat", price: 12000, category: "Snack" }
];

let cart = [];
let selectedCategory = 'all';

// Format angka ke mata uang Rupiah
function formatRupiah(amount) {
  return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(amount);
}

// Menampilkan Produk di Grid
function renderProducts(items) {
  const grid = document.getElementById('product-grid');
  grid.innerHTML = '';

  items.forEach(product => {
    const card = document.createElement('div');
    card.className = 'product-card';
    card.onclick = () => addToCart(product.id);
    card.innerHTML = `
      <div>
        <div class="product-category">${product.category}</div>
        <div class="product-name">${product.name}</div>
      </div>
      <div class="product-price">${formatRupiah(product.price)}</div>
    `;
    grid.appendChild(card);
  });
}

// Filter Berdasarkan Kategori
function filterCategory(category) {
  selectedCategory = category;
  document.querySelectorAll('.category-btn').forEach(btn => {
    btn.classList.toggle('active', btn.innerText.toLowerCase() === category.toLowerCase() || (category === 'all' && btn.innerText === 'Semua'));
  });
  applyFilters();
}

// Filter Berdasarkan Pencarian
function filterProducts() {
  applyFilters();
}

function applyFilters() {
  const query = document.getElementById('search-input').value.toLowerCase();
  const filtered = products.filter(p => {
    const matchesCategory = selectedCategory === 'all' || p.category === selectedCategory;
    const matchesSearch = p.name.toLowerCase().includes(query);
    return matchesCategory && matchesSearch;
  });
  renderProducts(filtered);
}

// Tambah Produk ke Keranjang
function addToCart(productId) {
  const product = products.find(p => p.id === productId);
  const existingItem = cart.find(item => item.id === productId);

  if (existingItem) {
    existingItem.qty += 1;
  } else {
    cart.push({ ...product, qty: 1 });
  }
  updateCartUI();
}

// Mengubah Kuantitas Produk di Keranjang
function changeQty(productId, change) {
  const item = cart.find(i => i.id === productId);
  if (item) {
    item.qty += change;
    if (item.qty <= 0) {
      cart = cart.filter(i => i.id !== productId);
    }
  }
  updateCartUI();
}

// Membersihkan Keranjang
function clearCart() {
  cart = [];
  document.getElementById('pay-amount').value = '';
  updateCartUI();
}

// Perbarui Tampilan Keranjang & Perhitungan
function updateCartUI() {
  const cartContainer = document.getElementById('cart-items');
  cartContainer.innerHTML = '';

  if (cart.length === 0) {
    cartContainer.innerHTML = '<p class="empty-msg">Keranjang masih kosong</p>';
  } else {
    cart.forEach(item => {
      const el = document.createElement('div');
      el.className = 'cart-item';
      el.innerHTML = `
        <div class="cart-item-details">
          <span class="cart-item-title">${item.name}</span>
          <span class="cart-item-price">${formatRupiah(item.price)} x ${item.qty}</span>
        </div>
        <div class="cart-item-controls">
          <button class="btn-qty" onclick="changeQty(${item.id}, -1)">-</button>
          <span>${item.qty}</span>
          <button class="btn-qty" onclick="changeQty(${item.id}, 1)">+</button>
        </div>
      `;
      cartContainer.appendChild(el);
    });
  }

  // Hitung Totals
  const subtotal = cart.reduce((sum, i) => sum + (i.price * i.qty), 0);
  const tax = subtotal * 0.1; // Pajak 10%
  const grandTotal = subtotal + tax;

  document.getElementById('subtotal').innerText = formatRupiah(subtotal);
  document.getElementById('tax').innerText = formatRupiah(tax);
  document.getElementById('grand-total').innerText = formatRupiah(grandTotal);

  calculateChange();
}

// Hitung Kembalian
function calculateChange() {
  const subtotal = cart.reduce((sum, i) => sum + (i.price * i.qty), 0);
  const grandTotal = subtotal + (subtotal * 0.1);
  const payAmount = parseFloat(document.getElementById('pay-amount').value) || 0;
  const change = payAmount - grandTotal;

  const changeEl = document.getElementById('change-amount');
  const checkoutBtn = document.getElementById('checkout-btn');

  if (change >= 0 && cart.length > 0) {
    changeEl.innerText = formatRupiah(change);
    checkoutBtn.disabled = false;
  } else {
    changeEl.innerText = payAmount > 0 ? "Uang kurang!" : "Rp 0";
    checkoutBtn.disabled = true;
  }
}

// Proses Transaksi dan Cetak Struk
function processCheckout() {
  const subtotal = cart.reduce((sum, i) => sum + (i.price * i.qty), 0);
  const tax = subtotal * 0.1;
  const grandTotal = subtotal + tax;
  const payAmount = parseFloat(document.getElementById('pay-amount').value) || 0;
  const change = payAmount - grandTotal;

  // Buat area cetak sementara
  let receiptHTML = `
    <div id="print-receipt">
      <h3 style="text-align:center;">KASIR kelompok2</h3>
      <p style="text-align:center;">Jl.UNMA</p>
      <hr style="border-top: 1px dashed #000; margin: 8px 0;">
      <p>Tanggal: ${new Date().toLocaleString('id-ID')}</p>
      <p>Kasir  : Admin</p>
      <hr style="border-top: 1px dashed #000; margin: 8px 0;">
  `;

  cart.forEach(item => {
    receiptHTML += `
      <div style="display:flex; justify-between;">
        <span>${item.name} (${item.qty}x)</span>
        <span>${formatRupiah(item.price * item.qty)}</span>
      </div>
    `;
  });

  receiptHTML += `
      <hr style="border-top: 1px dashed #000; margin: 8px 0;">
      <div style="display:flex; justify-content:space-between;"><span>Subtotal:</span><span>${formatRupiah(subtotal)}</span></div>
      <div style="display:flex; justify-content:space-between;"><span>Pajak (10%):</span><span>${formatRupiah(tax)}</span></div>
      <div style="display:flex; justify-content:space-between; font-weight:bold;"><span>TOTAL:</span><span>${formatRupiah(grandTotal)}</span></div>
      <div style="display:flex; justify-content:space-between;"><span>Bayar:</span><span>${formatRupiah(payAmount)}</span></div>
      <div style="display:flex; justify-content:space-between;"><span>Kembali:</span><span>${formatRupiah(change)}</span></div>
      <hr style="border-top: 1px dashed #000; margin: 8px 0;">
      <p style="text-align:center;">--- Terima Kasih ---</p>
    </div>
  `;

  // Sisipkan dan cetak
  const existingReceipt = document.getElementById('print-receipt');
  if (existingReceipt) existingReceipt.remove();

  document.body.insertAdjacentHTML('beforeend', receiptHTML);
  window.print();

  // Reset setelah bayar
  clearCart();
}

// Inisialisasi awal
renderProducts(products);