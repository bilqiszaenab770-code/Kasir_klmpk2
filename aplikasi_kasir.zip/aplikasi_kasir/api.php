<?php
header("Content-Type: application/json");
include "config.php";

$action = isset($_GET['action']) ? $_GET['action'] : '';

if ($action == 'get_produk') {
    $result = $conn->query("SELECT * FROM produk");
    $produk = [];
    while ($row = $result->fetch_assoc()) {
        $produk[] = $row;
    }
    echo json_encode($produk);
} 
elseif ($action == 'checkout') {
    $data = json_decode(file_get_contents("php://input"), true);
    
    $cart = $data['cart'];
    $bayar = $data['bayar'];
    $total = $data['total'];
    $kembalian = $bayar - $total;
    $no_nota = "NOTA-" . time();

    if ($bayar < $total) {
        echo json_encode(["success" => false, "message" => "Uang pembayaran kurang!"]);
        exit;
    }

    // Simpan ke tabel transaksi
    $conn->query("INSERT INTO transaksi (no_nota, total, bayar, kembalian) VALUES ('$no_nota', '$total', '$bayar', '$kembalian')");
    $transaksi_id = $conn->insert_id;

    // Simpan detail transaksi dan kurangi stok
    foreach ($cart as $item) {
        $produk_id = $item['id'];
        $jumlah = $item['qty'];
        $subtotal = $item['harga'] * $jumlah;

        $conn->query("INSERT INTO detail_transaksi (transaksi_id, produk_id, jumlah, subtotal) VALUES ('$transaksi_id', '$produk_id', '$jumlah', '$subtotal')");
        
        // Kurangi stok produk
        $conn->query("UPDATE produk SET stok = stok - $jumlah WHERE id = $produk_id");
    }

    echo json_encode(["success" => true, "message" => "Transaksi berhasil!", "nota" => $no_nota]);
}
?>